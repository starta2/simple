PhraseExpress USB Edition - Installation
----------------------------------------

Bitte kopieren Sie einfach den Inhalt dieser Archivdatei
in ein beliebiges Verzeichnis auf Ihrem USB Speicherstick.

Weitere Informationen:
http://handbuch.phraseexpress.de#usb

--

Please copy all files in this archive file into any
directory on your USB memory device.

Additional information:
http://manual.phraseexpress.com#usb



� 2002-2012 Bartels Media GmbH